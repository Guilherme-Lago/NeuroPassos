import { Linkedin, Mail } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const teamMembers = [
  {
    name: "Dra. Ana Paula Silva",
    role: "Psicóloga Clínica",
    specialty: "CRP 06/123456 | Especialista em Autismo",
    image: "https://images.unsplash.com/photo-1620148222862-b95cf7405a7b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjB0aGVyYXBpc3QlMjBjaGlsZHxlbnwxfHx8fDE3Njc4NDQxOTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    name: "Dra. Mariana Costa",
    role: "Fonoaudióloga",
    specialty: "CRFa 2-12345 | Linguagem e Comunicação",
    image: "https://images.unsplash.com/photo-1642035283356-0028a34f3145?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGlsZCUyMHRoZXJhcHklMjBjb2xvcmZ1bHxlbnwxfHx8fDE3Njc4NDQxOTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    name: "Dr. Roberto Oliveira",
    role: "Terapeuta Ocupacional",
    specialty: "CREFITO-3 123456 | Integração Sensorial",
    image: "https://images.unsplash.com/photo-1620148222862-b95cf7405a7b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjB0aGVyYXBpc3QlMjBjaGlsZHxlbnwxfHx8fDE3Njc4NDQxOTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    name: "Dra. Juliana Martins",
    role: "Psicopedagoga",
    specialty: "ABPp 1234 | Dificuldades de Aprendizagem",
    image: "https://images.unsplash.com/photo-1642035283356-0028a34f3145?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGlsZCUyMHRoZXJhcHklMjBjb2xvcmZ1bHxlbnwxfHx8fDE3Njc4NDQxOTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
];

export function Team() {
  return (
    <section id="equipe" className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Nossa Equipe
          </h2>
          <p className="text-lg text-gray-600">
            Profissionais qualificados e apaixonados pelo que fazem, com especialização em neurodivergência e anos de experiência no atendimento infantil.
          </p>
        </div>

        {/* Team Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {teamMembers.map((member, index) => (
            <div
              key={index}
              className="group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2"
            >
              <div className="relative h-72 overflow-hidden">
                <ImageWithFallback
                  src={member.image}
                  alt={member.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent"></div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-1">
                  {member.name}
                </h3>
                <p className="text-[#6366F1] font-semibold mb-2">
                  {member.role}
                </p>
                <p className="text-sm text-gray-600 mb-4">
                  {member.specialty}
                </p>
                
                <div className="flex gap-3">
                  <button className="p-2 rounded-full bg-gray-100 hover:bg-[#6366F1] hover:text-white transition-colors">
                    <Linkedin size={18} />
                  </button>
                  <button className="p-2 rounded-full bg-gray-100 hover:bg-[#EC4899] hover:text-white transition-colors">
                    <Mail size={18} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Call to Action */}
        <div className="mt-16 bg-gradient-to-r from-[#6366F1] to-[#EC4899] rounded-3xl p-8 md:p-12 text-center text-white">
          <h3 className="text-2xl md:text-3xl font-bold mb-4">
            Quer fazer parte da nossa equipe?
          </h3>
          <p className="text-lg mb-6 opacity-90">
            Estamos sempre em busca de profissionais dedicados e qualificados para se juntar ao nosso time.
          </p>
          <button className="bg-white text-[#6366F1] px-8 py-3 rounded-full hover:bg-gray-100 transition-colors font-semibold">
            Envie seu Currículo
          </button>
        </div>
      </div>
    </section>
  );
}
