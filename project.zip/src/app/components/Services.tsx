import { Baby, Brain, GraduationCap, BookOpen, Sparkles } from "lucide-react";

const services = [
  {
    icon: Baby,
    title: "Intervenção Precoce",
    description: "Identificação e atuação nos primeiros sinais de desenvolvimento atípico, maximizando o potencial de desenvolvimento da criança desde os primeiros meses de vida.",
    badge: "0-3 anos",
    color: "bg-[#E8F4F8]",
    iconColor: "text-[#4A90A4]",
    badgeColor: "bg-[#A8D5E2] text-white",
  },
  {
    icon: Brain,
    title: "Modelo Denver (ESDM)",
    description: "Abordagem naturalista e lúdica baseada em evidências para crianças com TEA, focada no desenvolvimento social, comunicativo e cognitivo através do brincar.",
    badge: "TEA",
    color: "bg-[#E0F7F2]",
    iconColor: "text-[#5CAD95]",
    badgeColor: "bg-[#7DD3C0] text-white",
  },
  {
    icon: Sparkles,
    title: "ABA (Análise do Comportamento Aplicada)",
    description: "Intervenção intensiva e individualizada para desenvolvimento de habilidades funcionais, redução de comportamentos desafiadores e autonomia no dia a dia.",
    badge: "Evidência Científica",
    color: "bg-[#FFF9E6]",
    iconColor: "text-[#E5B84A]",
    badgeColor: "bg-[#FFD97D] text-gray-800",
  },
  {
    icon: GraduationCap,
    title: "ABA na Escola",
    description: "Acompanhamento terapêutico no ambiente escolar para promover inclusão, adaptação curricular e desenvolvimento de habilidades acadêmicas e sociais.",
    badge: "Inclusão",
    color: "bg-[#FFEEF3]",
    iconColor: "text-[#D98BA5]",
    badgeColor: "bg-[#FFB4C8] text-white",
  },
  {
    icon: BookOpen,
    title: "VB-MAPP",
    description: "Avaliação de marcos do desenvolvimento verbal e de habilidades relacionadas para planejamento individualizado de intervenções e monitoramento de progresso.",
    badge: "Avaliação",
    color: "bg-[#F5F0F7]",
    iconColor: "text-[#A88DB5]",
    badgeColor: "bg-[#D4BBDD] text-white",
  },
];

export function Services() {
  return (
    <section id="servicos" className="py-20 bg-gradient-to-b from-[#E8F4F8] to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 bg-[#E0F7F2] border-2 border-[#7DD3C0] text-gray-700 px-4 py-2 rounded-full mb-4">
            <Sparkles size={20} className="text-[#5CAD95]" />
            <span className="font-semibold">Nossas Qualificações</span>
          </div>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
            Serviços Especializados
          </h2>
          <p className="text-lg text-gray-600">
            Metodologias baseadas em evidências científicas aplicadas com afeto e individualização
          </p>
        </div>

        {/* Services List */}
        <div className="space-y-6 mb-12">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <div
                key={index}
                className="group bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 border-2 border-gray-100 hover:border-[#A8D5E2]"
              >
                <div className="flex flex-col md:flex-row gap-6 items-start">
                  {/* Icon */}
                  <div className={`${service.color} w-20 h-20 rounded-2xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform`}>
                    <Icon size={36} className={service.iconColor} />
                  </div>

                  {/* Content */}
                  <div className="flex-1">
                    <div className="flex flex-wrap items-center gap-3 mb-3">
                      <h3 className="text-2xl font-bold text-gray-900">
                        {service.title}
                      </h3>
                      <span className={`${service.badgeColor} px-3 py-1 rounded-full text-sm font-semibold`}>
                        {service.badge}
                      </span>
                    </div>
                    <p className="text-gray-600 leading-relaxed text-lg">
                      {service.description}
                    </p>
                  </div>

                  {/* Number indicator */}
                  <div className="hidden lg:flex items-center justify-center w-16 h-16 rounded-full bg-gray-50 text-gray-300 font-bold text-2xl group-hover:bg-[#E8F4F8] group-hover:text-[#4A90A4] transition-colors">
                    {String(index + 1).padStart(2, '0')}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom Info Card */}
        <div className="bg-gradient-to-r from-[#E8F4F8] to-[#E0F7F2] rounded-3xl p-8 md:p-10">
          <div className="max-w-4xl mx-auto text-center">
            <h3 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
              Atendimento Integral e Personalizado
            </h3>
            <p className="text-lg text-gray-600 mb-6">
              Cada criança recebe um plano terapêutico individualizado, desenvolvido por nossa equipe multidisciplinar 
              com base em avaliações criteriosas e revisado constantemente para garantir os melhores resultados.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <div className="bg-white rounded-2xl px-6 py-3 shadow-md">
                <span className="text-[#4A90A4] font-bold text-lg">✓</span>
                <span className="ml-2 text-gray-700 font-medium">Plano Individualizado</span>
              </div>
              <div className="bg-white rounded-2xl px-6 py-3 shadow-md">
                <span className="text-[#5CAD95] font-bold text-lg">✓</span>
                <span className="ml-2 text-gray-700 font-medium">Supervisão Contínua</span>
              </div>
              <div className="bg-white rounded-2xl px-6 py-3 shadow-md">
                <span className="text-[#E5B84A] font-bold text-lg">✓</span>
                <span className="ml-2 text-gray-700 font-medium">Reavaliações Periódicas</span>
              </div>
              <div className="bg-white rounded-2xl px-6 py-3 shadow-md">
                <span className="text-[#D98BA5] font-bold text-lg">✓</span>
                <span className="ml-2 text-gray-700 font-medium">Parceria com Família</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
