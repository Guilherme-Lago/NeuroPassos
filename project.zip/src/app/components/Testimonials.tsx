import { Star, Quote } from "lucide-react";

const testimonials = [
  {
    name: "Maria Santos",
    role: "Mãe do Pedro, 6 anos",
    content: "A NeuroPassos transformou a vida do meu filho. A equipe é extremamente dedicada e o desenvolvimento dele tem sido incrível. Encontramos aqui o apoio que precisávamos.",
    rating: 5,
  },
  {
    name: "Carlos Ferreira",
    role: "Pai da Sofia, 8 anos",
    content: "Profissionais excepcionais que realmente entendem as necessidades das crianças neurodivergentes. A Sofia está mais confiante e feliz a cada dia.",
    rating: 5,
  },
  {
    name: "Juliana Alves",
    role: "Mãe do Lucas, 5 anos",
    content: "A abordagem multidisciplinar fez toda a diferença. Ver o progresso do Lucas na comunicação e nas atividades escolares tem sido emocionante. Gratidão eterna!",
    rating: 5,
  },
  {
    name: "Ricardo Costa",
    role: "Pai da Ana, 7 anos",
    content: "Ambiente acolhedor, profissionais qualificados e tratamento personalizado. A Ana adora vir para as sessões e isso diz muito sobre o trabalho da clínica.",
    rating: 5,
  },
];

export function Testimonials() {
  return (
    <section id="depoimentos" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            O que as Famílias Dizem
          </h2>
          <p className="text-lg text-gray-600">
            O feedback das famílias que atendemos é nossa maior motivação para continuar oferecendo o melhor atendimento.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-2 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="relative bg-gradient-to-br from-gray-50 to-white border border-gray-200 rounded-2xl p-8 hover:shadow-xl transition-all duration-300"
            >
              {/* Quote Icon */}
              <div className="absolute top-6 right-6 opacity-10">
                <Quote size={64} className="text-[#6366F1]" />
              </div>

              {/* Rating */}
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star
                    key={i}
                    size={20}
                    fill="#FCD34D"
                    className="text-[#FCD34D]"
                  />
                ))}
              </div>

              {/* Content */}
              <p className="text-gray-700 leading-relaxed mb-6 relative z-10">
                "{testimonial.content}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#6366F1] to-[#EC4899] flex items-center justify-center text-white font-bold text-lg">
                  {testimonial.name.charAt(0)}
                </div>
                <div>
                  <div className="font-bold text-gray-900">
                    {testimonial.name}
                  </div>
                  <div className="text-sm text-gray-600">
                    {testimonial.role}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Statistics */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          <div className="p-6">
            <div className="text-4xl font-bold text-[#6366F1] mb-2">98%</div>
            <div className="text-gray-600">Satisfação das Famílias</div>
          </div>
          <div className="p-6">
            <div className="text-4xl font-bold text-[#EC4899] mb-2">4.9/5</div>
            <div className="text-gray-600">Avaliação Média</div>
          </div>
          <div className="p-6">
            <div className="text-4xl font-bold text-[#8B5CF6] mb-2">500+</div>
            <div className="text-gray-600">Famílias Atendidas</div>
          </div>
          <div className="p-6">
            <div className="text-4xl font-bold text-[#F59E0B] mb-2">10+</div>
            <div className="text-gray-600">Anos de Experiência</div>
          </div>
        </div>
      </div>
    </section>
  );
}
