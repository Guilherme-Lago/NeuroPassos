import { Heart, ClipboardList, Target, TrendingUp } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const steps = [
  {
    number: "01",
    icon: Heart,
    title: "Acolhimento",
    description: "Recebemos a família com empatia e escuta ativa para compreender as necessidades, preocupações e expectativas em relação ao desenvolvimento da criança.",
    color: "bg-[#FFEEF3]",
    iconColor: "text-[#D98BA5]",
    borderColor: "border-[#FFB4C8]",
  },
  {
    number: "02",
    icon: ClipboardList,
    title: "Anamnese Completa",
    description: "Realizamos uma entrevista detalhada sobre o histórico de desenvolvimento, rotinas, comportamentos e contexto familiar para entender a criança de forma integral.",
    color: "bg-[#E8F4F8]",
    iconColor: "text-[#4A90A4]",
    borderColor: "border-[#A8D5E2]",
  },
  {
    number: "03",
    icon: Target,
    title: "Avaliação Personalizada",
    description: "Aplicamos ferramentas padronizadas e observação clínica para mapear habilidades, dificuldades e potencialidades, criando um perfil completo da criança.",
    color: "bg-[#FFF9E6]",
    iconColor: "text-[#E5B84A]",
    borderColor: "border-[#FFD97D]",
  },
  {
    number: "04",
    icon: TrendingUp,
    title: "Plano Terapêutico",
    description: "Desenvolvemos um plano de intervenção individualizado com metas claras, estratégias baseadas em evidências e monitoramento contínuo do progresso.",
    color: "bg-[#E0F7F2]",
    iconColor: "text-[#5CAD95]",
    borderColor: "border-[#7DD3C0]",
  },
];

export function Process() {
  return (
    <section id="processo" className="py-20 bg-white relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-1/4 right-0 w-96 h-96 bg-[#FFF9E6] rounded-full blur-3xl opacity-30"></div>
      <div className="absolute bottom-1/4 left-0 w-96 h-96 bg-[#FFEEF3] rounded-full blur-3xl opacity-30"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 bg-[#E0F7F2] border-2 border-[#7DD3C0] text-gray-700 px-4 py-2 rounded-full mb-4">
            <ClipboardList size={20} className="text-[#5CAD95]" />
            <span className="font-semibold">Nosso Processo</span>
          </div>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
            Passo a Passo do Atendimento
          </h2>
          <p className="text-lg text-gray-600">
            Uma jornada cuidadosa e estruturada para garantir o melhor desenvolvimento da criança
          </p>
        </div>

        {/* Process Steps */}
        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {steps.map((step, index) => {
            const Icon = step.icon;
            return (
              <div
                key={index}
                className={`relative bg-white border-2 ${step.borderColor} rounded-3xl p-8 hover:shadow-2xl transition-all duration-300 group`}
              >
                {/* Number badge */}
                <div className="absolute -top-4 -right-4 w-16 h-16 bg-gradient-to-br from-[#A8D5E2] to-[#7DD3C0] rounded-2xl flex items-center justify-center text-white font-bold text-xl shadow-lg transform group-hover:scale-110 transition-transform">
                  {step.number}
                </div>

                {/* Icon */}
                <div className={`${step.color} w-16 h-16 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                  <Icon size={32} className={step.iconColor} />
                </div>

                {/* Content */}
                <h3 className="text-2xl font-bold text-gray-900 mb-3">
                  {step.title}
                </h3>
                <p className="text-gray-600 leading-relaxed text-lg">
                  {step.description}
                </p>

                {/* Progress line (except for last items) */}
                {index < 2 && (
                  <div className="hidden md:block absolute top-1/2 -right-4 w-8 h-0.5 bg-gradient-to-r from-[#A8D5E2] to-transparent"></div>
                )}
              </div>
            );
          })}
        </div>

        {/* CTA Section with Image */}
        <div className="grid lg:grid-cols-2 gap-12 items-center bg-gradient-to-br from-[#E8F4F8] to-[#E0F7F2] rounded-[3rem] p-8 md:p-12">
          {/* Image */}
          <div className="order-2 lg:order-1">
            <div className="relative rounded-3xl overflow-hidden shadow-2xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1760113762872-631f32c7fab0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGlsZCUyMGRldmVsb3BtZW50JTIwYmxvY2tzfGVufDF8fHx8MTc2Nzg0NTAxNHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Desenvolvimento infantil com blocos"
                className="w-full h-[350px] object-cover"
              />
            </div>
          </div>

          {/* Content */}
          <div className="order-1 lg:order-2 space-y-6">
            <h3 className="text-3xl md:text-4xl font-bold text-gray-900">
              Pronto para dar o próximo passo?
            </h3>
            <p className="text-lg text-gray-700 leading-relaxed">
              Agende uma avaliação inicial e conheça como podemos apoiar o desenvolvimento do seu filho. 
              Nossa equipe está pronta para acolher você e sua família com todo o cuidado que vocês merecem.
            </p>
            
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 rounded-full bg-[#7DD3C0] flex items-center justify-center flex-shrink-0">
                  <span className="text-white text-sm font-bold">✓</span>
                </div>
                <span className="text-gray-700 font-medium">Primeira consulta sem compromisso</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 rounded-full bg-[#7DD3C0] flex items-center justify-center flex-shrink-0">
                  <span className="text-white text-sm font-bold">✓</span>
                </div>
                <span className="text-gray-700 font-medium">Relatório detalhado da avaliação</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 rounded-full bg-[#7DD3C0] flex items-center justify-center flex-shrink-0">
                  <span className="text-white text-sm font-bold">✓</span>
                </div>
                <span className="text-gray-700 font-medium">Orientações personalizadas para a família</span>
              </div>
            </div>

            <button
              onClick={() => {
                const element = document.getElementById("contato");
                if (element) element.scrollIntoView({ behavior: "smooth" });
              }}
              className="bg-[#FFD97D] text-gray-800 px-10 py-4 rounded-full hover:bg-[#FFC94D] transition-all shadow-lg hover:shadow-xl font-bold text-lg w-full sm:w-auto"
            >
              Agendar Avaliação Agora
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
