// Componentes de formas orgânicas para decoração
export function BlobShape1({ className = "" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 200 200"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <path
        fill="currentColor"
        d="M44.7,-76.4C58.8,-69.2,71.8,-59.1,79.6,-45.8C87.4,-32.6,90,-16.3,88.5,-0.9C87,14.6,81.4,29.2,73.1,42.3C64.8,55.4,53.8,67,40.4,74.3C27,81.6,11.2,84.6,-4.3,83.3C-19.8,82,-39.6,76.4,-54.5,66.2C-69.4,56,-79.4,41.2,-83.8,25.1C-88.2,9,-87,7.6,-82.6,-10.8C-78.2,-29.2,-70.6,-47.6,-58.4,-56.4C-46.2,-65.2,-29.4,-64.4,-14.1,-69.8C1.2,-75.2,30.6,-83.6,44.7,-76.4Z"
        transform="translate(100 100)"
      />
    </svg>
  );
}

export function BlobShape2({ className = "" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 200 200"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <path
        fill="currentColor"
        d="M39.5,-65.3C51.4,-58.5,61.7,-48.3,68.4,-36.2C75.1,-24.1,78.2,-10.1,77.8,3.7C77.4,17.5,73.5,31.1,65.8,42.2C58.1,53.3,46.6,61.9,33.8,67.4C21,72.9,7,75.3,-7.3,75.1C-21.6,74.9,-36.3,72.1,-48.2,64.8C-60.1,57.5,-69.2,45.7,-74.5,32.5C-79.8,19.3,-81.3,4.7,-78.9,-8.9C-76.5,-22.5,-70.2,-35.1,-60.8,-45.1C-51.4,-55.1,-39,-62.5,-26.1,-68.8C-13.2,-75.1,0.3,-80.3,13.3,-79.5C26.3,-78.7,27.6,-72.1,39.5,-65.3Z"
        transform="translate(100 100)"
      />
    </svg>
  );
}

export function PuzzlePiece({ className = "" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 100 100"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="currentColor"
    >
      <path d="M20,20 L45,20 C45,10 55,10 55,20 L80,20 L80,45 C90,45 90,55 80,55 L80,80 L55,80 C55,90 45,90 45,80 L20,80 L20,55 C10,55 10,45 20,45 Z" />
    </svg>
  );
}

export function BlockShape({ className = "" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 100 100"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="currentColor"
    >
      <rect x="10" y="30" width="35" height="35" rx="8" />
      <rect x="55" y="30" width="35" height="35" rx="8" opacity="0.7" />
      <rect x="32.5" y="55" width="35" height="35" rx="8" opacity="0.5" />
    </svg>
  );
}
