import { Menu, X, Phone } from "lucide-react";
import { useState } from "react";

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setMobileMenuOpen(false);
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-sm shadow-sm z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#A8D5E2] to-[#7DD3C0] flex items-center justify-center">
              <span className="text-white text-xl font-bold">N</span>
            </div>
            <div className="text-2xl font-bold">
              <span className="text-[#4A90A4]">Neuro</span>
              <span className="text-[#7DD3C0]">Passos</span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <button
              onClick={() => scrollToSection("inicio")}
              className="text-gray-700 hover:text-[#4A90A4] transition-colors font-medium"
            >
              Início
            </button>
            <button
              onClick={() => scrollToSection("sobre")}
              className="text-gray-700 hover:text-[#4A90A4] transition-colors font-medium"
            >
              Sobre Nós
            </button>
            <button
              onClick={() => scrollToSection("diferenciais")}
              className="text-gray-700 hover:text-[#4A90A4] transition-colors font-medium"
            >
              Diferenciais
            </button>
            <button
              onClick={() => scrollToSection("servicos")}
              className="text-gray-700 hover:text-[#4A90A4] transition-colors font-medium"
            >
              Serviços
            </button>
            <button
              onClick={() => scrollToSection("processo")}
              className="text-gray-700 hover:text-[#4A90A4] transition-colors font-medium"
            >
              Processo
            </button>
            <button
              onClick={() => scrollToSection("contato")}
              className="bg-[#FFD97D] text-gray-800 px-6 py-2.5 rounded-full hover:bg-[#FFC94D] transition-all shadow-md hover:shadow-lg flex items-center gap-2 font-semibold"
            >
              <Phone size={18} />
              Agendar Avaliação
            </button>
          </nav>

          {/* Mobile menu button */}
          <button
            className="md:hidden text-gray-700"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <nav className="md:hidden py-4 border-t">
            <div className="flex flex-col space-y-4">
              <button
                onClick={() => scrollToSection("inicio")}
                className="text-gray-700 hover:text-[#4A90A4] transition-colors text-left font-medium"
              >
                Início
              </button>
              <button
                onClick={() => scrollToSection("sobre")}
                className="text-gray-700 hover:text-[#4A90A4] transition-colors text-left font-medium"
              >
                Sobre Nós
              </button>
              <button
                onClick={() => scrollToSection("diferenciais")}
                className="text-gray-700 hover:text-[#4A90A4] transition-colors text-left font-medium"
              >
                Diferenciais
              </button>
              <button
                onClick={() => scrollToSection("servicos")}
                className="text-gray-700 hover:text-[#4A90A4] transition-colors text-left font-medium"
              >
                Serviços
              </button>
              <button
                onClick={() => scrollToSection("processo")}
                className="text-gray-700 hover:text-[#4A90A4] transition-colors text-left font-medium"
              >
                Processo
              </button>
              <button
                onClick={() => scrollToSection("contato")}
                className="bg-[#FFD97D] text-gray-800 px-6 py-3 rounded-full hover:bg-[#FFC94D] transition-all text-center font-semibold shadow-md"
              >
                Agendar Avaliação
              </button>
            </div>
          </nav>
        )}
      </div>
    </header>
  );
}
