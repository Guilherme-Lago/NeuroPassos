import { Award, Brain, Heart, DollarSign, Users, Lightbulb } from "lucide-react";

const differentials = [
  {
    icon: Users,
    title: "Equipe Multidisciplinar Qualificada",
    description: "Profissionais especializados em neurodivergência com formação contínua em práticas baseadas em evidências.",
    color: "bg-[#E8F4F8]",
    iconColor: "text-[#4A90A4]",
    borderColor: "border-[#A8D5E2]",
  },
  {
    icon: Brain,
    title: "Metodologia Baseada em Evidências",
    description: "ABA, Modelo Denver, VB-MAPP e outras abordagens cientificamente comprovadas para resultados efetivos.",
    color: "bg-[#E0F7F2]",
    iconColor: "text-[#5CAD95]",
    borderColor: "border-[#7DD3C0]",
  },
  {
    icon: Heart,
    title: "Atendimento Humanizado",
    description: "Acolhimento genuíno às famílias com escuta ativa, empatia e respeito à individualidade de cada criança.",
    color: "bg-[#FFEEF3]",
    iconColor: "text-[#D98BA5]",
    borderColor: "border-[#FFB4C8]",
  },
  {
    icon: Lightbulb,
    title: "Tecnologia e Estrutura Adaptada",
    description: "Ambiente sensorial adequado com recursos tecnológicos e materiais especializados para cada necessidade.",
    color: "bg-[#F5F0F7]",
    iconColor: "text-[#A88DB5]",
    borderColor: "border-[#D4BBDD]",
  },
  {
    icon: Award,
    title: "Supervisão Especializada",
    description: "Supervisão contínua em ABA e Modelo Denver para garantir a qualidade e eficácia das intervenções.",
    color: "bg-[#FFF9E6]",
    iconColor: "text-[#E5B84A]",
    borderColor: "border-[#FFD97D]",
  },
  {
    icon: DollarSign,
    title: "Acessibilidade Financeira",
    description: "Opções de pagamento flexíveis e convênios para tornar o tratamento acessível a mais famílias.",
    color: "bg-[#FFE8E0]",
    iconColor: "text-[#D98B6A]",
    borderColor: "border-[#FFBE98]",
  },
];

export function Differentials() {
  return (
    <section id="diferenciais" className="py-20 bg-white relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute top-0 right-0 w-72 h-72 bg-[#E8F4F8] rounded-full blur-3xl opacity-40"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-[#E0F7F2] rounded-full blur-3xl opacity-40"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 bg-[#FFF9E6] border-2 border-[#FFD97D] text-gray-700 px-4 py-2 rounded-full mb-4">
            <Award size={20} className="text-[#E5B84A]" />
            <span className="font-semibold">Nossos Diferenciais</span>
          </div>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
            O que nos torna únicos
          </h2>
          <p className="text-lg text-gray-600">
            Competências e compromissos que fazem da NeuroPassos uma referência em desenvolvimento infantil
          </p>
        </div>

        {/* Differentials Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {differentials.map((differential, index) => {
            const Icon = differential.icon;
            return (
              <div
                key={index}
                className={`group relative bg-white border-2 ${differential.borderColor} rounded-3xl p-8 hover:shadow-2xl transition-all duration-300 hover:-translate-y-2`}
              >
                {/* Icon background */}
                <div className={`${differential.color} w-16 h-16 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <Icon size={32} className={differential.iconColor} />
                </div>
                
                <h3 className="text-xl font-bold text-gray-900 mb-3">
                  {differential.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {differential.description}
                </p>

                {/* Hover effect - decorative corner */}
                <div className={`absolute top-0 right-0 w-20 h-20 ${differential.color} rounded-bl-full opacity-0 group-hover:opacity-30 transition-opacity duration-300`}></div>
              </div>
            );
          })}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-16">
          <p className="text-gray-600 mb-6 text-lg">
            Quer conhecer mais sobre como trabalhamos?
          </p>
          <button
            onClick={() => {
              const element = document.getElementById("contato");
              if (element) element.scrollIntoView({ behavior: "smooth" });
            }}
            className="bg-[#FFD97D] text-gray-800 px-10 py-4 rounded-full hover:bg-[#FFC94D] transition-all shadow-lg hover:shadow-xl font-bold text-lg"
          >
            Entre em Contato
          </button>
        </div>
      </div>
    </section>
  );
}
