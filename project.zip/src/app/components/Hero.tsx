import { ArrowRight, Sparkles, Heart } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { BlobShape1, BlobShape2 } from "./shapes/OrganicShapes";

export function Hero() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="inicio" className="relative pt-28 pb-20 overflow-hidden">
      {/* Background decorativo com formas orgânicas */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-0 left-0 w-96 h-96 opacity-20">
          <BlobShape1 className="text-[#A8D5E2] w-full h-full" />
        </div>
        <div className="absolute bottom-0 right-0 w-80 h-80 opacity-20">
          <BlobShape2 className="text-[#FFB4C8] w-full h-full" />
        </div>
        <div className="absolute top-1/3 right-1/4 w-64 h-64 opacity-10">
          <BlobShape1 className="text-[#7DD3C0] w-full h-full" />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="space-y-6 relative z-10">
            <div className="inline-flex items-center gap-2 bg-[#FFF9E6] border-2 border-[#FFD97D] text-gray-700 px-4 py-2 rounded-full">
              <Sparkles size={20} className="text-[#FFD97D]" />
              <span className="font-semibold">Cuidado Especializado</span>
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
              Desenvolvimento Infantil com Base em{" "}
              <span className="relative inline-block">
                <span className="text-[#4A90A4]">Evidências</span>
                <svg className="absolute -bottom-2 left-0 w-full h-3" viewBox="0 0 200 12" preserveAspectRatio="none">
                  <path d="M0,7 Q50,0 100,7 T200,7" fill="none" stroke="#7DD3C0" strokeWidth="4" strokeLinecap="round"/>
                </svg>
              </span>
              {" "}e{" "}
              <span className="relative inline-block">
                <span className="text-[#7DD3C0]">Afeto</span>
                <Heart size={28} className="absolute -top-1 -right-8 text-[#FFB4C8] fill-[#FFB4C8]" />
              </span>
            </h1>
            
            <p className="text-lg md:text-xl text-gray-600 leading-relaxed">
              Atendimento especializado em neurodivergência com supervisão em <strong>ABA</strong> e <strong>Modelo Denver</strong>. Transformamos vidas através da inclusão, do desenvolvimento integral e do respeito à singularidade de cada criança.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <button
                onClick={() => scrollToSection("contato")}
                className="bg-[#FFD97D] text-gray-800 px-8 py-4 rounded-full hover:bg-[#FFC94D] transition-all flex items-center justify-center gap-2 shadow-lg hover:shadow-xl font-bold text-lg"
              >
                Agendar Avaliação
                <ArrowRight size={22} />
              </button>
              <button
                onClick={() => scrollToSection("sobre")}
                className="border-3 border-[#A8D5E2] text-[#4A90A4] px-8 py-4 rounded-full hover:bg-[#E8F4F8] transition-all font-bold text-lg"
              >
                Saiba Mais
              </button>
            </div>

            {/* Stats com design lúdico */}
            <div className="grid grid-cols-3 gap-6 pt-8">
              <div className="bg-[#E8F4F8] rounded-3xl p-5 text-center transform hover:scale-105 transition-transform">
                <div className="text-3xl md:text-4xl font-bold text-[#4A90A4]">10+</div>
                <div className="text-sm text-gray-600 mt-1 font-medium">Anos de Experiência</div>
              </div>
              <div className="bg-[#E0F7F2] rounded-3xl p-5 text-center transform hover:scale-105 transition-transform">
                <div className="text-3xl md:text-4xl font-bold text-[#5CAD95]">500+</div>
                <div className="text-sm text-gray-600 mt-1 font-medium">Famílias Transformadas</div>
              </div>
              <div className="bg-[#FFEEF3] rounded-3xl p-5 text-center transform hover:scale-105 transition-transform">
                <div className="text-3xl md:text-4xl font-bold text-[#D98BA5]">15+</div>
                <div className="text-sm text-gray-600 mt-1 font-medium">Especialistas</div>
              </div>
            </div>
          </div>

          {/* Image com decorações */}
          <div className="relative">
            <div className="relative rounded-[3rem] overflow-hidden shadow-2xl transform hover:scale-[1.02] transition-transform duration-500">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1620230874645-0d85522b20f9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0aGVyYXB5JTIwY2hpbGQlMjBhdXRpc218ZW58MXx8fHwxNzY3ODQ1MDE0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Terapia com criança"
                className="w-full h-[500px] object-cover"
              />
              {/* Overlay gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#A8D5E2]/20 to-transparent"></div>
            </div>
            
            {/* Elementos decorativos flutuantes */}
            <div className="absolute -top-6 -right-6 w-20 h-20 bg-[#FFD97D] rounded-full opacity-80 blur-xl animate-pulse"></div>
            <div className="absolute -bottom-6 -left-6 w-24 h-24 bg-[#7DD3C0] rounded-full opacity-60 blur-xl animate-pulse" style={{ animationDelay: "1s" }}></div>
          </div>
        </div>
      </div>
    </section>
  );
}
