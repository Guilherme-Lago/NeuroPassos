import { Target, Users, Sparkles } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { PuzzlePiece } from "./shapes/OrganicShapes";

export function About() {
  return (
    <section id="sobre" className="py-20 bg-gradient-to-b from-white to-[#E8F4F8]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center justify-center gap-2 mb-4">
            <div className="w-12 h-12">
              <PuzzlePiece className="text-[#A8D5E2] w-full h-full" />
            </div>
          </div>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
            Sobre a NeuroPassos
          </h2>
          <p className="text-lg text-gray-600">
            Um agente transformador na vida de pessoas neurodivergentes
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          {/* Image */}
          <div className="relative order-2 lg:order-1">
            <div className="relative rounded-[3rem] overflow-hidden shadow-2xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1761048370427-494e01030f97?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmNsdXNpdmUlMjBlZHVjYXRpb24lMjBjaGlsZHJlbnxlbnwxfHx8fDE3Njc4NDUwMTV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Educação inclusiva"
                className="w-full h-[450px] object-cover"
              />
            </div>
            {/* Decorative circle */}
            <div className="absolute -bottom-8 -right-8 w-32 h-32 bg-[#7DD3C0] rounded-full opacity-30 blur-2xl"></div>
          </div>

          {/* Content */}
          <div className="space-y-6 order-1 lg:order-2">
            <div className="bg-white rounded-3xl p-8 shadow-lg border-2 border-[#E0F7F2] hover:shadow-xl transition-shadow">
              <div className="flex items-start gap-4">
                <div className="w-14 h-14 rounded-2xl bg-[#E8F4F8] flex items-center justify-center flex-shrink-0">
                  <Target size={28} className="text-[#4A90A4]" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">Nossa Missão</h3>
                  <p className="text-gray-600 leading-relaxed">
                    Ser um agente transformador na vida de pessoas neurodivergentes, promovendo o desenvolvimento integral, a inclusão social e o bem-estar através de práticas baseadas em evidências científicas e muito afeto.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-3xl p-8 shadow-lg border-2 border-[#FFF9E6] hover:shadow-xl transition-shadow">
              <div className="flex items-start gap-4">
                <div className="w-14 h-14 rounded-2xl bg-[#FFF9E6] flex items-center justify-center flex-shrink-0">
                  <Sparkles size={28} className="text-[#E5B84A]" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">Nossa Visão</h3>
                  <p className="text-gray-600 leading-relaxed">
                    Ser referência em atendimento especializado para crianças neurodivergentes, reconhecida pela excelência técnica, inovação nas intervenções e compromisso com a humanização do cuidado.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-3xl p-8 shadow-lg border-2 border-[#FFEEF3] hover:shadow-xl transition-shadow">
              <div className="flex items-start gap-4">
                <div className="w-14 h-14 rounded-2xl bg-[#FFEEF3] flex items-center justify-center flex-shrink-0">
                  <Users size={28} className="text-[#D98BA5]" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">Nossos Valores</h3>
                  <p className="text-gray-600 leading-relaxed">
                    <strong>Acolhimento, Respeito, Inclusão e Evidência Científica.</strong> Acreditamos na potencialidade única de cada criança e trabalhamos com solidariedade e comprometimento para que ela alcance seu máximo desenvolvimento.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Commitment Banner */}
        <div className="relative bg-gradient-to-r from-[#A8D5E2] via-[#7DD3C0] to-[#FFD97D] rounded-[3rem] p-10 md:p-12 text-center overflow-hidden">
          {/* Background pattern */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-4 left-4 w-20 h-20">
              <PuzzlePiece className="text-white w-full h-full" />
            </div>
            <div className="absolute bottom-4 right-4 w-24 h-24">
              <PuzzlePiece className="text-white w-full h-full" />
            </div>
          </div>
          
          <div className="relative z-10">
            <h3 className="text-2xl md:text-3xl font-bold text-white mb-4">
              Compromisso com o Desenvolvimento e Bem-Estar Infantil
            </h3>
            <p className="text-lg text-white/90 max-w-3xl mx-auto">
              Cada criança é única e merece um atendimento que respeite suas necessidades individuais. 
              Nossa equipe está comprometida em oferecer o melhor suporte para o desenvolvimento pleno 
              de cada pequeno que passa por nossas portas.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
