import { MapPin, Phone, Mail, Clock, Send, MessageCircle } from "lucide-react";
import { useState } from "react";
import { PuzzlePiece } from "./shapes/OrganicShapes";

export function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    childAge: "",
    subject: "",
    message: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Aqui seria implementada a lógica de envio do formulário
    alert("Mensagem enviada com sucesso! Entraremos em contato em breve para acolher você e sua família. 💚");
    setFormData({ name: "", email: "", phone: "", childAge: "", subject: "", message: "" });
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <section id="contato" className="py-20 bg-gradient-to-b from-white to-[#E8F4F8] relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute top-10 left-10 w-24 h-24 opacity-10">
        <PuzzlePiece className="text-[#A8D5E2] w-full h-full" />
      </div>
      <div className="absolute bottom-10 right-10 w-32 h-32 opacity-10">
        <PuzzlePiece className="text-[#7DD3C0] w-full h-full" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 bg-[#FFF9E6] border-2 border-[#FFD97D] text-gray-700 px-4 py-2 rounded-full mb-4">
            <MessageCircle size={20} className="text-[#E5B84A]" />
            <span className="font-semibold">Fale Conosco</span>
          </div>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
            Vamos Conversar?
          </h2>
          <p className="text-lg text-gray-600">
            Estamos aqui para acolher você e sua família. Entre em contato e dê o primeiro passo para transformar a vida do seu filho.
          </p>
        </div>

        <div className="grid lg:grid-cols-5 gap-12">
          {/* Contact Information */}
          <div className="lg:col-span-2 space-y-6">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-6">
                Informações de Contato
              </h3>
              <div className="space-y-5">
                {/* Address */}
                <div className="flex gap-4 bg-white rounded-2xl p-5 shadow-md border-2 border-[#E8F4F8] hover:border-[#A8D5E2] transition-colors">
                  <div className="w-12 h-12 rounded-xl bg-[#E8F4F8] text-[#4A90A4] flex items-center justify-center flex-shrink-0">
                    <MapPin size={24} />
                  </div>
                  <div>
                    <div className="font-bold text-gray-900 mb-1">
                      Endereço
                    </div>
                    <div className="text-gray-600 text-sm">
                      Rua das Flores, 123 - Centro<br />
                      São Paulo, SP - CEP 01234-567
                    </div>
                  </div>
                </div>

                {/* Phone */}
                <div className="flex gap-4 bg-white rounded-2xl p-5 shadow-md border-2 border-[#E0F7F2] hover:border-[#7DD3C0] transition-colors">
                  <div className="w-12 h-12 rounded-xl bg-[#E0F7F2] text-[#5CAD95] flex items-center justify-center flex-shrink-0">
                    <Phone size={24} />
                  </div>
                  <div>
                    <div className="font-bold text-gray-900 mb-1">
                      Telefone
                    </div>
                    <div className="text-gray-600 text-sm">
                      (11) 3456-7890<br />
                      (11) 98765-4321 (WhatsApp)
                    </div>
                  </div>
                </div>

                {/* Email */}
                <div className="flex gap-4 bg-white rounded-2xl p-5 shadow-md border-2 border-[#FFF9E6] hover:border-[#FFD97D] transition-colors">
                  <div className="w-12 h-12 rounded-xl bg-[#FFF9E6] text-[#E5B84A] flex items-center justify-center flex-shrink-0">
                    <Mail size={24} />
                  </div>
                  <div>
                    <div className="font-bold text-gray-900 mb-1">
                      E-mail
                    </div>
                    <div className="text-gray-600 text-sm">
                      contato@neuropassos.com.br<br />
                      agendamento@neuropassos.com.br
                    </div>
                  </div>
                </div>

                {/* Hours */}
                <div className="flex gap-4 bg-white rounded-2xl p-5 shadow-md border-2 border-[#FFEEF3] hover:border-[#FFB4C8] transition-colors">
                  <div className="w-12 h-12 rounded-xl bg-[#FFEEF3] text-[#D98BA5] flex items-center justify-center flex-shrink-0">
                    <Clock size={24} />
                  </div>
                  <div>
                    <div className="font-bold text-gray-900 mb-1">
                      Horário de Atendimento
                    </div>
                    <div className="text-gray-600 text-sm">
                      Segunda a Sexta: 8h às 18h<br />
                      Sábado: 8h às 12h
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Commitment message */}
            <div className="bg-gradient-to-br from-[#A8D5E2] to-[#7DD3C0] rounded-3xl p-6 text-white">
              <h4 className="font-bold text-lg mb-2">Nosso Compromisso</h4>
              <p className="text-sm text-white/90">
                Cada família é acolhida com empatia, escuta ativa e respeito. 
                Estamos aqui para caminhar ao seu lado nesta jornada de desenvolvimento e inclusão.
              </p>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-3">
            <form onSubmit={handleSubmit} className="bg-white rounded-3xl shadow-2xl p-8 md:p-10 border-2 border-gray-100 space-y-6">
              <h3 className="text-2xl font-bold text-gray-900 mb-2">
                Envie sua Mensagem
              </h3>
              <p className="text-gray-600 mb-6">
                Preencha o formulário abaixo e nossa equipe entrará em contato em até 24 horas.
              </p>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-bold text-gray-700 mb-2">
                    Seu Nome Completo *
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-[#A8D5E2] focus:border-[#A8D5E2] outline-none transition-all"
                    placeholder="Maria Silva"
                  />
                </div>

                <div>
                  <label htmlFor="phone" className="block text-sm font-bold text-gray-700 mb-2">
                    Telefone / WhatsApp *
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-[#A8D5E2] focus:border-[#A8D5E2] outline-none transition-all"
                    placeholder="(11) 98765-4321"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="email" className="block text-sm font-bold text-gray-700 mb-2">
                    E-mail *
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-[#A8D5E2] focus:border-[#A8D5E2] outline-none transition-all"
                    placeholder="maria@email.com"
                  />
                </div>

                <div>
                  <label htmlFor="childAge" className="block text-sm font-bold text-gray-700 mb-2">
                    Idade da Criança
                  </label>
                  <input
                    type="text"
                    id="childAge"
                    name="childAge"
                    value={formData.childAge}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-[#A8D5E2] focus:border-[#A8D5E2] outline-none transition-all"
                    placeholder="Ex: 5 anos"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="subject" className="block text-sm font-bold text-gray-700 mb-2">
                  Como podemos ajudar? *
                </label>
                <select
                  id="subject"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-[#A8D5E2] focus:border-[#A8D5E2] outline-none transition-all"
                >
                  <option value="">Selecione uma opção</option>
                  <option value="avaliacao">Agendar Avaliação Inicial</option>
                  <option value="informacoes">Informações sobre Serviços</option>
                  <option value="aba">Informações sobre ABA</option>
                  <option value="denver">Informações sobre Modelo Denver</option>
                  <option value="convenio">Convênios e Valores</option>
                  <option value="outro">Outra Dúvida</option>
                </select>
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-bold text-gray-700 mb-2">
                  Conte-nos mais *
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={5}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-[#A8D5E2] focus:border-[#A8D5E2] outline-none transition-all resize-none"
                  placeholder="Compartilhe suas dúvidas, preocupações ou expectativas. Estamos aqui para ouvir você..."
                />
              </div>

              <button
                type="submit"
                className="w-full bg-[#FFD97D] text-gray-800 px-8 py-4 rounded-xl hover:bg-[#FFC94D] transition-all flex items-center justify-center gap-2 font-bold text-lg shadow-lg hover:shadow-xl"
              >
                <Send size={22} />
                Enviar Mensagem
              </button>

              <p className="text-sm text-gray-500 text-center">
                * Campos obrigatórios. Respeitamos sua privacidade e não compartilhamos seus dados.
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
