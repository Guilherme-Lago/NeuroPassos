import { Heart, Instagram, Facebook, Linkedin, Mail, Phone } from "lucide-react";
import { PuzzlePiece } from "./shapes/OrganicShapes";

export function Footer() {
  return (
    <footer className="bg-gradient-to-br from-gray-900 to-gray-800 text-white relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-10 right-10 w-32 h-32 opacity-5">
        <PuzzlePiece className="text-white w-full h-full" />
      </div>
      <div className="absolute bottom-10 left-10 w-24 h-24 opacity-5">
        <PuzzlePiece className="text-white w-full h-full" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 relative z-10">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#A8D5E2] to-[#7DD3C0] flex items-center justify-center">
                <span className="text-white text-2xl font-bold">N</span>
              </div>
              <div className="text-2xl font-bold">
                <span className="text-[#A8D5E2]">Neuro</span>
                <span className="text-[#7DD3C0]">Passos</span>
              </div>
            </div>
            <p className="text-gray-400 mb-6 leading-relaxed">
              Transformando vidas através do desenvolvimento infantil com base em evidências e muito afeto.
            </p>
            <div className="flex gap-3">
              <a
                href="#"
                className="w-11 h-11 rounded-xl bg-gray-800 hover:bg-[#A8D5E2] hover:text-gray-900 flex items-center justify-center transition-all"
              >
                <Instagram size={20} />
              </a>
              <a
                href="#"
                className="w-11 h-11 rounded-xl bg-gray-800 hover:bg-[#7DD3C0] hover:text-gray-900 flex items-center justify-center transition-all"
              >
                <Facebook size={20} />
              </a>
              <a
                href="#"
                className="w-11 h-11 rounded-xl bg-gray-800 hover:bg-[#FFD97D] hover:text-gray-900 flex items-center justify-center transition-all"
              >
                <Linkedin size={20} />
              </a>
              <a
                href="#"
                className="w-11 h-11 rounded-xl bg-gray-800 hover:bg-[#FFB4C8] hover:text-gray-900 flex items-center justify-center transition-all"
              >
                <Mail size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-bold text-lg mb-4">Navegação</h3>
            <ul className="space-y-3">
              <li>
                <a href="#inicio" className="text-gray-400 hover:text-[#A8D5E2] transition-colors flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#7DD3C0]"></span>
                  Início
                </a>
              </li>
              <li>
                <a href="#sobre" className="text-gray-400 hover:text-[#A8D5E2] transition-colors flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#7DD3C0]"></span>
                  Sobre Nós
                </a>
              </li>
              <li>
                <a href="#diferenciais" className="text-gray-400 hover:text-[#A8D5E2] transition-colors flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#7DD3C0]"></span>
                  Diferenciais
                </a>
              </li>
              <li>
                <a href="#servicos" className="text-gray-400 hover:text-[#A8D5E2] transition-colors flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#7DD3C0]"></span>
                  Serviços
                </a>
              </li>
              <li>
                <a href="#processo" className="text-gray-400 hover:text-[#A8D5E2] transition-colors flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#7DD3C0]"></span>
                  Processo
                </a>
              </li>
              <li>
                <a href="#contato" className="text-gray-400 hover:text-[#A8D5E2] transition-colors flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#7DD3C0]"></span>
                  Contato
                </a>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="font-bold text-lg mb-4">Nossas Especialidades</h3>
            <ul className="space-y-3 text-gray-400 text-sm">
              <li className="flex items-start gap-2">
                <span className="text-[#FFD97D] mt-1">▪</span>
                Intervenção Precoce
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#FFD97D] mt-1">▪</span>
                Modelo Denver (ESDM)
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#FFD97D] mt-1">▪</span>
                ABA (Análise do Comportamento)
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#FFD97D] mt-1">▪</span>
                ABA na Escola
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#FFD97D] mt-1">▪</span>
                VB-MAPP
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#FFD97D] mt-1">▪</span>
                Atendimento Multidisciplinar
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-bold text-lg mb-4">Contato Rápido</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <Phone size={18} className="text-[#7DD3C0] mt-1 flex-shrink-0" />
                <div className="text-gray-400 text-sm">
                  <div>(11) 3456-7890</div>
                  <div>(11) 98765-4321</div>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <Mail size={18} className="text-[#FFD97D] mt-1 flex-shrink-0" />
                <div className="text-gray-400 text-sm">
                  <div>contato@neuropassos.com.br</div>
                </div>
              </li>
            </ul>

            <div className="mt-6 bg-gradient-to-r from-[#A8D5E2]/20 to-[#7DD3C0]/20 rounded-2xl p-4 border border-[#A8D5E2]/30">
              <p className="text-sm text-gray-300">
                <strong className="text-white">Horário:</strong><br />
                Seg a Sex: 8h às 18h<br />
                Sábado: 8h às 12h
              </p>
            </div>
          </div>
        </div>

        {/* Commitment Banner */}
        <div className="border-t border-gray-700 pt-8 mb-8">
          <div className="bg-gradient-to-r from-[#A8D5E2]/10 to-[#7DD3C0]/10 rounded-2xl p-6 text-center border border-[#A8D5E2]/20">
            <p className="text-gray-300 text-lg font-medium">
              <Heart size={20} className="inline-block text-[#FFB4C8] fill-[#FFB4C8] mr-2" />
              Compromisso com o desenvolvimento e o bem-estar infantil
              <Heart size={20} className="inline-block text-[#FFB4C8] fill-[#FFB4C8] ml-2" />
            </p>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-700 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-gray-400 text-sm text-center md:text-left">
            © 2026 NeuroPassos - Clínica de Desenvolvimento Infantil. Todos os direitos reservados.
          </div>
          <div className="flex items-center gap-2 text-gray-400 text-sm">
            <span>Desenvolvido com</span>
            <Heart size={16} fill="currentColor" className="text-[#FFB4C8]" />
            <span>para famílias e crianças</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
